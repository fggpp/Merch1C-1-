const products = [
    {
        id: 1,
        name: "Футболка 1С",
        price: 1500,
        image: "images/products/tshirt.jpg",
        description: "Фирменная футболка с символикой 1С. Отличный вариант для повседневной носки."
    },
    {
        id: 2,
        name: "Кружка 1С",
        price: 700,
        image: "images/products/mug.jpg",
        description: "Кружка с фирменным дизайном для любителей продукции 1С."
    },
    {
        id: 3,
        name: "Худи 1С",
        price: 3500,
        image: "images/products/hoodie.jpg",
        description: "Удобное худи с символикой 1С."
    },
    {
        id: 4,
        name: "Сумка 1С",
        price: 900,
        image: "images/products/bag.jpg",
        description: "Практичная сумка с фирменной символикой."
    }
];

const params = new URLSearchParams(window.location.search);
const id = Number(params.get("id"));

const product = products.find(item => item.id === id);
const container = document.getElementById("product-details");

if (!product) {
    container.innerHTML = "<h2>Товар не найден</h2>";
} else {
    document.title = product.name + " | 1С Мерч";

    container.innerHTML = `
        <div class="product-detail-image">
            <img src="${product.image}" alt="${product.name}">
        </div>

        <div class="product-detail-info">
            <p class="eyebrow">КАТАЛОГ 1С МЕРЧ</p>
            <h1>${product.name}</h1>
            <p>${product.description}</p>
            <h2>${product.price} ₽</h2>

            <button class="main-button" onclick="addToCart()">
                Добавить в корзину
            </button>

            <p id="message"></p>
        </div>
    `;
}

function addToCart() {
    let cart = JSON.parse(localStorage.getItem("merchCart")) || [];

    const existing = cart.find(item => item.id === product.id);

    if (existing) {
        existing.quantity++;
    } else {
        cart.push({...product, quantity: 1});
    }

    localStorage.setItem("merchCart", JSON.stringify(cart));

    document.getElementById("message").textContent =
        "Товар добавлен в корзину!";
}