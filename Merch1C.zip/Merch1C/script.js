const products = [
    {
        id: 1,
        name: "Футболка 1С",
        price: 1500,
        category: "clothing",
        image: "images/products/tshirt.jpg",
        description: "Фирменная футболка с символикой 1С."
    },
    {
        id: 2,
        name: "Кружка 1С",
        price: 700,
        category: "accessories",
        image: "images/products/mug.jpg",
        description: "Кружка с фирменным дизайном."
    },
    {
        id: 3,
        name: "Худи 1С",
        price: 3500,
        category: "clothing",
        image: "images/products/hoodie.jpg",
        description: "Удобное худи с символикой 1С."
    },
    {
        id: 4,
        name: "Сумка 1С",
        price: 900,
        category: "accessories",
        image: "images/products/bag.jpg",
        description: "Практичная фирменная сумка."
    }
];

// Корзина
let cart = JSON.parse(localStorage.getItem("merchCart")) || [];

// Данные личного кабинета
let users = JSON.parse(localStorage.getItem("merchUsers")) || [];
let currentUser = JSON.parse(localStorage.getItem("merchCurrentUser")) || null;

// Защита от вставки HTML из пользовательских данных
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[char]);
}

// ==============================
// КАТАЛОГ
// ==============================

function renderProducts() {
    const container = document.getElementById("products");

    const search = document.getElementById("search-input").value.toLowerCase().trim();
    const category = document.getElementById("category-filter").value;
    const sort = document.getElementById("sort-filter").value;

    let filteredProducts = products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(search);
        const matchesCategory = category === "all" || product.category === category;

        return matchesSearch && matchesCategory;
    });

    if (sort === "cheap") {
        filteredProducts.sort((a, b) => a.price - b.price);
    }

    if (sort === "expensive") {
        filteredProducts.sort((a, b) => b.price - a.price);
    }

    if (filteredProducts.length === 0) {
        container.innerHTML = "<p>Товары не найдены.</p>";
        return;
    }

    container.innerHTML = filteredProducts.map(product => `
        <article class="product-card">
            <div class="product-image">
                <img
                    src="${product.image}"
                    alt="${product.name}"
                    onclick="openLightbox('${product.image}', '${product.name}')"
                >
            </div>

            <div class="product-info">
                <h3>${product.name}</h3>
                <p class="product-price">${product.price} ₽</p>

                <div class="product-actions">
                    <button class="details-button"
                        onclick="showDetails(${product.id})">
                        Подробнее
                    </button>

                    <button onclick="addToCart(${product.id})">
                        В корзину
                    </button>
                </div>
            </div>
        </article>
    `).join("");
}

// ==============================
// УВЕДОМЛЕНИЯ
// ==============================

function showToast(message) {
    const container = document.getElementById("toast-container");

    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add("toast-hide");

        setTimeout(() => toast.remove(), 300);
    }, 2500);
}

// ==============================
// УВЕЛИЧЕНИЕ ФОТОГРАФИЙ
// ==============================

function openLightbox(image, name) {
    const lightbox = document.getElementById("lightbox");
    const imageElement = document.getElementById("lightbox-image");

    imageElement.src = image;
    imageElement.alt = name;

    lightbox.classList.add("active");
}

function closeLightbox() {
    document.getElementById("lightbox").classList.remove("active");
}

// ==============================
// КОРЗИНА
// ==============================

function addToCart(id) {
    const product = products.find(item => item.id === id);
    const existing = cart.find(item => item.id === id);

    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    saveCart();
    showToast(`${product.name} добавлен в корзину!`);
}

function saveCart() {
    localStorage.setItem("merchCart", JSON.stringify(cart));
    renderCart();
}

function renderCart() {
    const container = document.getElementById("cart-items");

    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

    document.getElementById("cart-count").textContent = count;
    document.getElementById("cart-total").textContent = total + " ₽";

    if (cart.length === 0) {
        container.innerHTML = "<p>Корзина пока пуста.</p>";
        return;
    }

    container.innerHTML = cart.map(item => `
        <div class="cart-item">
            <strong>${item.name}</strong>
            <p>${item.price} ₽ × ${item.quantity}</p>
            <button onclick="changeQuantity(${item.id}, -1)">−</button>
            <button onclick="changeQuantity(${item.id}, 1)">+</button>
            <button onclick="removeFromCart(${item.id})">Удалить</button>
        </div>
    `).join("");
}

function changeQuantity(id, change) {
    const item = cart.find(product => product.id === id);

    if (!item) return;

    item.quantity += change;

    if (item.quantity <= 0) {
        removeFromCart(id);
    } else {
        saveCart();
    }
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
}

function openCart() {
    document.getElementById("cart-panel").classList.add("active");
    document.getElementById("cart-overlay").classList.add("active");
}

function closeCart() {
    document.getElementById("cart-panel").classList.remove("active");
    document.getElementById("cart-overlay").classList.remove("active");
}

function showDetails(id) {
    window.location.href = "product.html?id=" + id;
}

function checkout() {
    if (cart.length === 0) {
        showToast("Сначала добавьте товары в корзину.");
        return;
    }

    document.getElementById("checkout-overlay").classList.add("active");
}

function closeCheckout() {
    document.getElementById("checkout-overlay").classList.remove("active");
}

async function submitOrder(event) {
    event.preventDefault();

    if (cart.length === 0) {
        showToast("Корзина пуста.");
        return;
    }

    const order = {
        customer: {
            name: document.getElementById("order-name").value.trim(),
            email: document.getElementById("order-email").value.trim(),
            phone: document.getElementById("order-phone").value.trim()
        },
        delivery: {
            address: document.getElementById("order-address").value.trim(),
            comment: document.getElementById("order-comment").value.trim()
        },
        items: cart.map(item => ({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity
        }))
    };

    try {
        const response = await fetch("http://localhost:3000/api/orders", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(order)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || "Ошибка оформления заказа");
        }

        showToast("Заказ " + result.orderNumber + " оформлен!");

        cart = [];
        saveCart();

        document.getElementById("checkout-form").reset();
        closeCheckout();
        closeCart();

    } catch (error) {
        console.error(error);
        showToast("Не удалось оформить заказ. Проверьте сервер и почту.");
    }
}

document.getElementById("checkout-form")
    .addEventListener("submit", submitOrder);

// ==============================
// ЛИЧНЫЙ КАБИНЕТ
// ==============================

function saveUsers() {
    localStorage.setItem("merchUsers", JSON.stringify(users));
}

function saveCurrentUser() {
    localStorage.setItem("merchCurrentUser", JSON.stringify(currentUser));
}

function openAccount() {
    document.getElementById("account-overlay").classList.add("active");
    renderAccount();
}

function closeAccount() {
    document.getElementById("account-overlay").classList.remove("active");
}

function renderAccount() {
    const container = document.getElementById("account-content");

    if (currentUser) {
        container.innerHTML = `
            <h2>Личный кабинет</h2>
            <p>Добро пожаловать, ${escapeHTML(currentUser.name)}!</p>

            <form onsubmit="updateProfile(event)">
                <label>Имя</label>
                <input id="profile-name" value="${escapeHTML(currentUser.name)}" required>

                <label>Электронная почта</label>
                <input type="email" value="${escapeHTML(currentUser.email)}" disabled>

                <label>Телефон</label>
                <input id="profile-phone" value="${escapeHTML(currentUser.phone || "")}" placeholder="+7 ...">

                <button type="submit">Сохранить изменения</button>
            </form>

            <button onclick="logoutUser()">Выйти из аккаунта</button>
        `;
    } else {
        container.innerHTML = `
            <h2>Личный кабинет</h2>

            <div class="account-tabs">
                <button onclick="showLoginForm()">Вход</button>
                <button onclick="showRegisterForm()">Регистрация</button>
            </div>

            <div id="account-form">
                ${getLoginForm()}
            </div>
        `;
    }
}

function getLoginForm() {
    return `
        <h3>Вход в аккаунт</h3>

        <form onsubmit="loginUser(event)">
            <label>Электронная почта</label>
            <input type="email" id="login-email" required>

            <label>Пароль</label>
            <input type="password" id="login-password" required>

            <button type="submit">Войти</button>
        </form>
    `;
}

function getRegisterForm() {
    return `
        <h3>Создание аккаунта</h3>

        <form onsubmit="registerUser(event)">
            <label>Имя</label>
            <input type="text" id="register-name" required>

            <label>Электронная почта</label>
            <input type="email" id="register-email" required>

            <label>Телефон</label>
            <input type="tel" id="register-phone">

            <label>Пароль</label>
            <input type="password" id="register-password" minlength="6" required>

            <button type="submit">Зарегистрироваться</button>
        </form>
    `;
}

function showLoginForm() {
    document.getElementById("account-form").innerHTML = getLoginForm();
}

function showRegisterForm() {
    document.getElementById("account-form").innerHTML = getRegisterForm();
}

function registerUser(event) {
    event.preventDefault();

    const name = document.getElementById("register-name").value.trim();
    const email = document.getElementById("register-email").value.trim().toLowerCase();
    const phone = document.getElementById("register-phone").value.trim();
    const password = document.getElementById("register-password").value;

    if (users.some(user => user.email === email)) {
        showToast("Этот адрес уже зарегистрирован.");
        return;
    }

    const user = { name, email, phone, password };

    users.push(user);
    saveUsers();

    currentUser = { name, email, phone };
    saveCurrentUser();

    renderAccount();
    showToast("Аккаунт успешно создан!");
}

function loginUser(event) {
    event.preventDefault();

    const email = document.getElementById("login-email").value.trim().toLowerCase();
    const password = document.getElementById("login-password").value;

    const user = users.find(item =>
        item.email === email && item.password === password
    );

    if (!user) {
        showToast("Неверная почта или пароль.");
        return;
    }

    currentUser = {
        name: user.name,
        email: user.email,
        phone: user.phone
    };

    saveCurrentUser();
    renderAccount();
    showToast("Вы успешно вошли!");
}

function updateProfile(event) {
    event.preventDefault();

    const name = document.getElementById("profile-name").value.trim();
    const phone = document.getElementById("profile-phone").value.trim();

    const user = users.find(item => item.email === currentUser.email);

    if (!user) return;

    user.name = name;
    user.phone = phone;

    currentUser.name = name;
    currentUser.phone = phone;

    saveUsers();
    saveCurrentUser();

    renderAccount();
    showToast("Профиль обновлён!");
}

function logoutUser() {
    currentUser = null;
    localStorage.removeItem("merchCurrentUser");

    renderAccount();
    showToast("Вы вышли из аккаунта.");
}

// ==============================
// ПОИСК И ФИЛЬТРЫ
// ==============================

document.getElementById("search-input")
    .addEventListener("input", renderProducts);

document.getElementById("category-filter")
    .addEventListener("change", renderProducts);

document.getElementById("sort-filter")
    .addEventListener("change", renderProducts);

document.getElementById("reset-filters")
    .addEventListener("click", function() {
        document.getElementById("search-input").value = "";
        document.getElementById("category-filter").value = "all";
        document.getElementById("sort-filter").value = "default";

        renderProducts();
    });

// Закрытие увеличенного фото по клавише Escape
document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        closeLightbox();
        closeAccount();
    }
});

// Запуск магазина
renderProducts();
renderCart();

