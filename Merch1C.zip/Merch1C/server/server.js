const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());

// Проверка работы сервера
app.get("/", (req, res) => {
    res.send("Merch1C: сервер работает!");
});

// Создание заказа и отправка писем
app.post("/api/orders", async (req, res) => {
    try {
        const { customer, items, delivery } = req.body;

        if (
            !customer?.name ||
            !customer?.email ||
            !customer?.phone ||
            !delivery?.address ||
            !Array.isArray(items) ||
            items.length === 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Заполните все данные заказа."
            });
        }

        const orderNumber =
            "ORD-" + Date.now().toString().slice(-8);

        const orderItems = items.map(item => {
            return `${item.name} — ${item.quantity} шт. × ${item.price} ₽`;
        }).join("\n");

        const total = items.reduce((sum, item) => {
            return sum + item.price * item.quantity;
        }, 0);

        const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: Number(process.env.SMTP_PORT),
            secure: process.env.SMTP_SECURE === "true",
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
            }
        });

        // Письмо менеджеру
        await transporter.sendMail({
            from: process.env.MAIL_FROM,
            to: process.env.MANAGER_EMAIL,
            subject: `Новый заказ ${orderNumber}`,
            text: `
Новый заказ Merch1C

Номер: ${orderNumber}

Клиент: ${customer.name}
Почта: ${customer.email}
Телефон: ${customer.phone}

Товары:
${orderItems}

Итого: ${total} ₽

Доставка:
${delivery.address}
${delivery.comment || ""}
            `
        });

        // Письмо клиенту
        await transporter.sendMail({
            from: process.env.MAIL_FROM,
            to: customer.email,
            subject: `Ваш заказ ${orderNumber} принят`,
            text: `
Здравствуйте, ${customer.name}!

Ваш заказ принят в работу. Скоро мы с вами свяжемся.

Номер заказа: ${orderNumber}

С уважением,
Команда Юманс-ВЦ
            `
        });

        res.json({
            success: true,
            orderNumber,
            message: "Заказ оформлен. Уведомления отправлены."
        });

    } catch (error) {
        console.error("Ошибка оформления заказа:", error);

        res.status(500).json({
            success: false,
            message: "Не удалось оформить заказ."
        });
    }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Merch1C server запущен: http://localhost:${PORT}`);
});